<?php
namespace App\Controller;

class CursosController extends AppController {
    
    public function index() {
        $rgs = $this->Cursos->find('all');
        $this->set('rgs',$rgs);
        //pr( $rgs->toArray() );
    }
    
    public function add(){
        $curso = $this->Cursos->newEntity();
        
        if($this->request->is('post')){
            //salvar os dados
            $curso = $this->Cursos->patchEntity($curso, 
                            $this->request->getData());
            if($this->Cursos->save($curso)){
                //sucesso
                $this->Flash->success('Cadastro Efetuado com sucesso.');
                $this->redirect('/cursos/index');
            }else{
                //erro
                $this->Flash->error('Errro no Cadastro');
            }
        }
        
        $this->set('curso', $curso);
    }
    
    public function delete($id=null) {
        $this->request->allowMethod(['post', 'put']);
        
        $curso = $this->Cursos->get($id);
        if( $this->Cursos->delete($curso) ){
            //sucesso
            $this->Flash->success('Regitro excluído com sucesso!');
        }else{
            //erro
            $this->Flash->error('Erro na exclusão');
        }
        
        $this->redirect('/cursos/index');
    }
    
    public function edit($id=null) {
        $curso = $this->Cursos->get($id);
        
        if($this->request->is(['post', 'put'])){
            //alterar os dados
            $curso = $this->Cursos->patchEntity($curso, 
                            $this->request->getData());
            if($this->Cursos->save($curso)){
                //sucesso
                $this->Flash->success('Edição Efetuada com sucesso.');
                $this->redirect('/cursos/index');
            }else{
                //erro
                $this->Flash->error('Errro na Edição');
            }
        }
        
        $this->set('curso', $curso);
    }
}
