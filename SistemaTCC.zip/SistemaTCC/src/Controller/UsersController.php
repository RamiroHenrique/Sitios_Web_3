<?php

namespace App\Controller;

use App\Controller\AppController;

class UsersController extends AppController {

    public function initialize() {
        parent::initialize();
        $this->Auth->allow(['add']);
    }

    public function add() {
        $user = $this->Users->newEntity();

        if ($this->request->is('post')) {
            //salvar os dados
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                //sucesso
                $this->Flash->success('Cadastro Efetuado com sucesso.');
                $this->redirect('/users/add');
            } else {
                //erro
                $this->Flash->error('Errro no Cadastro');
            }
        }

        $this->set('user', $user);
    }

    public function login() {
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                return $this->redirect($this->Auth->redirectUrl());
            }
            $this->Flash->error('Usuário ou Senha incorreto');
        }
    }

}
