<?php
namespace App\Controller;

class CronogramasController extends AppController {
    
    public function index() {
        $rgs = $this->Cronogramas->find('all');
        $this->set('rgs',$rgs);
        //pr( $rgs->toArray() );
    }
    
    public function add(){
        $cronograma = $this->Cronogramas->newEntity();
        
        if($this->request->is('post')){
            //salvar os dados
            $cronograma = $this->Cronogramas->patchEntity($cronograma, 
                            $this->request->getData());
            if($this->Cronogramas->save($cronograma)){
                //sucesso
                $this->Flash->success('Cadastro Efetuado com sucesso.');
                $this->redirect('/cronogramas/index');
            }else{
                //erro
                $this->Flash->error('Errro no Cadastro');
            }
        }
        
        $this->set('cronograma', $cronograma);
    }
    
    public function delete($id=null) {
        $this->request->allowMethod(['post', 'put']);
        
        $cronograma = $this->Cronogramas->get($id);
        if( $this->Cronogramas->delete($cronograma) ){
            //sucesso
            $this->Flash->success('Regitro excluído com sucesso!');
        }else{
            //erro
            $this->Flash->error('Erro na exclusão');
        }
        
        $this->redirect('/cronogramas/index');
    }
    
    public function edit($id=null) {
        $cronograma = $this->Cronogramas->get($id);
        
        if($this->request->is(['post', 'put'])){
            //alterar os dados
            $cronograma = $this->Cronogramas->patchEntity($cronograma, 
                            $this->request->getData());
            if($this->Cronogramas->save($cronograma)){
                //sucesso
                $this->Flash->success('Edição Efetuada com sucesso.');
                $this->redirect('/cronogramas/index');
            }else{
                //erro
                $this->Flash->error('Errro na Edição');
            }
        }
        
        $this->set('cronograma', $cronograma);
    }
}
