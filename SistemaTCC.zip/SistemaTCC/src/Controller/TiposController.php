<?php
namespace App\Controller;

class TiposController extends AppController {
    
    public function index() {
        $rgs = $this->Tipos->find('all')
                ->contain('Projetos');
        $this->set('rgs',$rgs);
        //pr( $rgs->toArray() );
    }
    
    public function add(){
        $tipo = $this->Tipos->newEntity();
        
        if($this->request->is('post')){
            //salvar os dados
            $tipo = $this->Tipos->patchEntity($tipo, 
                            $this->request->getData());
            if($this->Tipos->save($tipo)){
                //sucesso
                $this->Flash->success('Cadastro Efetuado com sucesso.');
                $this->redirect('/tipos/index');
            }else{
                //erro
                $this->Flash->error('Errro no Cadastro');
            }
        }
        
        $this->set('tipo', $tipo);
    }
    
    public function delete($id=null) {
        $this->request->allowMethod(['post', 'put']);
        
        $tipo = $this->Tipos->get($id);
        if( $this->Tipos->delete($tipo) ){
            //sucesso
            $this->Flash->success('Regitro excluído com sucesso!');
        }else{
            //erro
            $this->Flash->error('Erro na exclusão');
        }
        
        $this->redirect('/tipos/index');
    }
    
    public function edit($id=null) {
        $tipo = $this->Tipos->get($id);
        
        if($this->request->is(['post', 'put'])){
            //alterar os dados
            $tipo = $this->Tipos->patchEntity($tipo, 
                            $this->request->getData());
            if($this->Tipos->save($tipo)){
                //sucesso
                $this->Flash->success('Edição Efetuada com sucesso.');
                $this->redirect('/tipos/index');
            }else{
                //erro
                $this->Flash->error('Errro na Edição');
            }
        }
        
        $this->set('tipo', $tipo);
    }
}
