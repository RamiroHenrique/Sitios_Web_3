<?php
namespace App\Controller;

class DefesasController extends AppController {
    
    public function index() {
        $rgs = $this->Defesas->find('all')
                ->contain(['Projetos', 'Professores']);
        $this->set('rgs',$rgs);
        //pr( $rgs->toArray() );
    }
    
    public function add(){
        $defesa = $this->Defesas->newEntity();
        
        if($this->request->is('post')){
            //salvar os dados
            $defesa = $this->Defesas->patchEntity($defesa, 
                            $this->request->getData());
            if($this->Defesas->save($defesa)){
                //sucesso
                $this->Flash->success('Cadastro Efetuado com sucesso.');
                $this->redirect('/defesas/index');
            }else{
                //erro
                $this->Flash->error('Errro no Cadastro');
            }
        }
        
        $this->set('defesa', $defesa);
        
        $projetos = $this->Defesas->Projetos->find('list', [
           'keyField' => 'id',
           'valueField' => 'titulo'
        ]);
        $this->set(compact('projetos'));
        
        $professores = $this->Defesas->Professores->find('list',[
            'keyField' => 'id',
            'valueField' => 'nome',
            'order' => 'nome'
        ]);
        $this->set(compact('professores'));
    }
    
    public function delete($id=null) {
        $this->request->allowMethod(['post', 'put']);
        
        $defesa = $this->Defesas->get($id);
        if( $this->Defesas->delete($defesa) ){
            //sucesso
            $this->Flash->success('Regitro excluído com sucesso!');
        }else{
            //erro
            $this->Flash->error('Erro na exclusão');
        }
        
        $this->redirect('/defesas/index');
    }
    
    public function edit($id=null) {
        $defesa = $this->Defesas->get($id, [
            'contain' => ['Professores']
        ]);
        
        if($this->request->is(['post', 'put'])){
            //alterar os dados
            $defesa = $this->Defesas->patchEntity($defesa, 
                            $this->request->getData());
            if($this->Defesas->save($defesa)){
                //sucesso
                $this->Flash->success('Edição Efetuada com sucesso.');
                $this->redirect('/defesas/index');
            }else{
                //erro
                $this->Flash->error('Errro na Edição');
            }
        }
        
        $this->set('defesa', $defesa);
        
        $projetos = $this->Defesas->Projetos->find('list', [
           'keyField' => 'id',
           'valueField' => 'titulo'
        ]);
        $this->set(compact('projetos'));
        
        $professores = $this->Defesas->Professores->find('list',[
            'keyField' => 'id',
            'valueField' => 'nome',
            'order' => 'nome'
        ]);
        $this->set(compact('professores'));
    }
}
