<?php
namespace App\Controller;

class ProjetosController extends AppController {
    
    public function index() {
        $rgs = $this->Projetos->find('all')
                ->contain(['Tipos']);
        $this->set('rgs', $rgs);
        //pr( $rgs->toArray() );
    }
    
    public function add() {
        $projeto = $this->Projetos->newEntity();
        if($this->request->is('post')){
            $projeto = $this->Projetos->patchEntity(
                    $projeto, $this->request->getData());
            
            if($this->Projetos->save($projeto)){
                $this->Flash->success('Cadastro efetuado com sucesso');
                $this->redirect('\projetos\index');
            }else{
                $this->Flash->error('Erro no cadastro');
            }
        }        
        $this->set(compact('projeto'));
        
        $tipos = $this->Projetos->Tipos->find('list',[
            'keyField' => 'id',
            'valueField' => 'descricao',
            'order' => 'descricao'
        ]);
        $this->set(compact('tipos'));
    }
    
    public function edit($id=null) {
        $projeto = $this->Projetos->get($id);
        if($this->request->is(['post','put'])){
            $projeto = $this->Projetos->patchEntity(
                    $projeto, $this->request->getData());
            
            if($this->Projetos->save($projeto)){
                $this->Flash->success('Edição efetuada com sucesso');
                $this->redirect('\projetos\index');
            }else{
                $this->Flash->error('Erro na edição');
            }
        }        
        $this->set(compact('projeto'));
        
        $tipos = $this->Projetos->Tipos->find('list',[
            'keyField' => 'id',
            'valueField' => 'descricao',
            'order' => 'descricao'
        ]);
        $this->set(compact('tipos'));
    }
      
    public function delete($id=null) {
        $this->request->allowMethod(['post', 'put']);
        
        $projeto = $this->Projetos->get($id);
        if( $this->Projetos->delete($projeto) ){
            $this->Flash->success('Regitro excluído com sucesso!');
        }else{
            $this->Flash->error('Erro na exclusão');
        }
        
        $this->redirect('/projetos/index');
    }
    
}
