<?php
namespace App\Model\Table;
use Cake\ORM\Table;


class TiposTable extends Table {
    
    public function initialize(array $config) {
        $this->setTable('tipo');
        $this->addBehavior('Timestamp');
        
        $this->hasMany('Projetos', [
            'foreignKey' => 'tipo_id'
        ]);
    }
    
}
