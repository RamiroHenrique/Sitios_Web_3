<?php
namespace App\Model\Table;
use Cake\ORM\Table;

class DefesasTable extends Table {
    
    public function initialize(array $config) {
        $this->setTable('defesa');
        $this->addBehavior('Timestamp');
        
        $this->belongsTo('Projetos', [
            'foreignKey' => 'projeto_id'
        ]);
        
        $this->belongsToMany('Professores', [
            'foreignKey' => 'defesa_id',
            'joinTable' => 'professor_banca',
            'targetForeignKey' => 'professor_id',
            'propertyName' => 'banca'
        ]);
    }
    
}
