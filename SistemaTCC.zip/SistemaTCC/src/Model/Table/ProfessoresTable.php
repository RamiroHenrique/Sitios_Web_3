<?php
namespace App\Model\Table;
use Cake\ORM\Table;

class ProfessoresTable extends Table {
    
    public function initialize(array $config) {
        $this->setTable('professor');
        $this->addBehavior('Timestamp');
    }
    
}
