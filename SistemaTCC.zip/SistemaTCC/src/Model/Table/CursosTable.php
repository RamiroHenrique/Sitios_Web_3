<?php
namespace App\Model\Table;
use Cake\ORM\Table;


class CursosTable extends Table {
    
    public function initialize(array $config) {
        $this->setTable('curso');
        $this->addBehavior('Timestamp');
    }
    
}
