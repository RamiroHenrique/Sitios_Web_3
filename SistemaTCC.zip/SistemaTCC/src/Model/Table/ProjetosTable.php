<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class ProjetosTable extends Table {
    
    public function initialize(array $config) {
        $this->setTable('projeto');
        $this->addBehavior('Timestamp');
        
        $this->belongsTo('Tipos', [
            'foreignKey' => 'tipo_id'
        ]);  
    }
    
    public function validationDefault(Validator $validator){
        $validator
                ->notEmpty('tipo_id', 'Tipo do projeto é obrigatório')
                ->add('semestre_inicio', [
                        'length' => [
                            'rule' => ['minLength', 5],
                            'message' => 'Semestre de Início é obrigatório']])
                ->notEmpty('fase', 'Fase é obrigatório')
                ->add('titulo', [
                        'length' => [
                            'rule' => ['minLength', 10],
                            'message' => 'Título mínimo com 10 caracteres']]);
        
        return $validator;
    }
    
}
