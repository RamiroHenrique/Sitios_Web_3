<?php
namespace App\Model\Entity;
use Cake\ORM\Entity;

class Defesa extends Entity{

    protected function _setData($value){
        if (!empty($value)){
            return implode('-', array_reverse(explode('/', $value)));
        }
    }
}