<?php
namespace App\Model\Entity;

use Cake\Auth\DefaultPasswordHasher; // Add this line
use Cake\ORM\Entity;

class User extends Entity
{

    protected function _setSenha($value){
        if (strlen($value)){
            $hasher = new DefaultPasswordHasher();
            return $hasher->hash($value);
        }
    }
}