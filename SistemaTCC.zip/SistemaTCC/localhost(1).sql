-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Tempo de geração: 16/04/2018 às 20:20
-- Versão do servidor: 5.7.20-0ubuntu0.16.04.1
-- Versão do PHP: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistema_tcc`
--
CREATE DATABASE IF NOT EXISTS `sistema_tcc` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sistema_tcc`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cronograma`
--

CREATE TABLE `cronograma` (
  `id` int(10) UNSIGNED NOT NULL,
  `semestre` char(6) DEFAULT NULL,
  `fase` enum('TCC1','TCC2') DEFAULT NULL,
  `versao_banca` date DEFAULT NULL,
  `inicio_defesas` date DEFAULT NULL,
  `versao_final` date DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `cronograma`
--

INSERT INTO `cronograma` (`id`, `semestre`, `fase`, `versao_banca`, `inicio_defesas`, `versao_final`, `created`, `modified`) VALUES
(1, '2018-1', 'TCC1', '2018-05-20', '2018-05-27', '2018-06-05', '2018-04-12 01:39:58', '2018-04-12 01:39:58');

-- --------------------------------------------------------

--
-- Estrutura para tabela `curso`
--

CREATE TABLE `curso` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `curso`
--

INSERT INTO `curso` (`id`, `descricao`, `created`, `modified`) VALUES
(2, 'Tecnologia em Sistemas para Internet', '2018-04-12 00:09:50', '2018-04-12 00:09:50'),
(3, 'Engenharia Eletrônica', '2018-04-12 00:10:07', '2018-04-12 00:10:07');

-- --------------------------------------------------------

--
-- Estrutura para tabela `projeto`
--

CREATE TABLE `projeto` (
  `id` int(10) UNSIGNED NOT NULL,
  `tipo_id` int(10) UNSIGNED NOT NULL,
  `semestre_inicio` char(6) DEFAULT NULL,
  `fase` enum('TCC1','TCC2') DEFAULT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  `resumo` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `projeto`
--

INSERT INTO `projeto` (`id`, `tipo_id`, `semestre_inicio`, `fase`, `titulo`, `resumo`, `created`, `modified`) VALUES
(1, 1, '2018-1', 'TCC1', 'Título de Teste', 'Resumo de teste', '2018-04-16 00:00:00', '2018-04-16 00:00:00'),
(2, 3, '2018-1', 'TCC1', 'Teste Desenvolvimento', 'teste', '2018-04-16 23:06:59', '2018-04-16 23:06:59');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo`
--

CREATE TABLE `tipo` (
  `id` int(10) UNSIGNED NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `informacoes` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `tipo`
--

INSERT INTO `tipo` (`id`, `descricao`, `informacoes`, `created`, `modified`) VALUES
(1, 'Pesquisa', 'Pesquisa', '2018-04-12 01:17:49', '2018-04-12 01:17:49'),
(2, 'Revisão de Literatura', 'Revisão', '2018-04-12 01:18:06', '2018-04-12 01:18:06'),
(3, 'Desenvolvimento de Software', 'Desenvolvimento', '2018-04-12 01:18:21', '2018-04-12 01:18:21'),
(4, 'Relato de Caso', 'Relato de Caso', '2018-04-12 01:18:40', '2018-04-12 01:18:40');

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `cronograma`
--
ALTER TABLE `cronograma`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `projeto`
--
ALTER TABLE `projeto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_projeto_tipo_idx` (`tipo_id`);

--
-- Índices de tabela `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `cronograma`
--
ALTER TABLE `cronograma`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `curso`
--
ALTER TABLE `curso`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de tabela `projeto`
--
ALTER TABLE `projeto`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de tabela `tipo`
--
ALTER TABLE `tipo`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `projeto`
--
ALTER TABLE `projeto`
  ADD CONSTRAINT `fk_projeto_tipo` FOREIGN KEY (`tipo_id`) REFERENCES `tipo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
